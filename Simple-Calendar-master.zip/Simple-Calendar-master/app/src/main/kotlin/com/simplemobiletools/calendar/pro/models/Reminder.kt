package com.simplemobiletools.calendar.pro.models

data class Reminder(val minutes: Int, val type: Int)
